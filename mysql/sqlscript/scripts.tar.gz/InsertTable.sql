/* INSERT  MATERIAL */
insert into material values ('LAP-D123','LAPTOP','Laptop DELL 123','Laptop 15');
insert into material values ('LAP-A123','LAPTOP','Laptop ASUS ROG 5','Laptop ASUS ROG 15', 10);
insert into material values ('LAP-D111','LAPTOP','Laptop DELL 111','Laptop 15', 15);
insert into material values ('MOU-G555','MOUSE','Mouse Generic','Mouse Generic - Laser', 50);

/* INSERT STOCK */
insert into stock values ('LAP-D123','CENTRO', 15);
insert into stock values ('LAP-D123','SUR', 18);
insert into stock values ('LAP-A123','NORTE', 10);
insert into stock values ('LAP-D111','SUR', 15);
insert into stock values ('MOU-G555','ESTE', 50);